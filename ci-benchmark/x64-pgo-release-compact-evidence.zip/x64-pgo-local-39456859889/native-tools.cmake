set(CMAKE_LINKER "C:/q56859889l/r/citools/clang-rust/bin/lld-link.exe" CACHE FILEPATH "" FORCE)
set(CMAKE_AR "C:/q56859889l/r/citools/clang-rust/bin/llvm-lib.exe" CACHE FILEPATH "" FORCE)
