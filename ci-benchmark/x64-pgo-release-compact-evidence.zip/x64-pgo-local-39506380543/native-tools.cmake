set(CMAKE_LINKER "C:/q06380543l/r/citools/clang-rust/bin/lld-link.exe" CACHE FILEPATH "" FORCE)
set(CMAKE_AR "C:/q06380543l/r/citools/clang-rust/bin/llvm-lib.exe" CACHE FILEPATH "" FORCE)
