import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import tempfile
import time


def main():
    root = Path(__file__).resolve().parent
    cache = root / "sccache.exe"
    clang = Path(r"C:\Program Files\LLVM\bin\clang-cl.exe")
    profiles = root.parent / "upstream-51dae-performance"
    output = root / f"reproduction-{time.time_ns()}"
    output.mkdir()
    records = []
    env = {key: value for key, value in os.environ.items() if not key.upper().startswith("SCCACHE_")}

    def run(command, label, success=True):
        command = [str(item) for item in command]
        completed = subprocess.run(command, cwd=work, env=env, capture_output=True, text=True, timeout=60)
        (output / f"{label}.stdout").write_text(completed.stdout)
        (output / f"{label}.stderr").write_text(completed.stderr)
        records.append({"label": label, "command": command, "exit_code": completed.returncode})
        if (completed.returncode == 0) != success:
            raise RuntimeError(f"{label} returned {completed.returncode}: {completed.stderr}")
        return completed

    with tempfile.TemporaryDirectory(prefix="isolated-work-", dir=root) as temporary:
        work = Path(temporary)
        with socket.socket() as reservation:
            reservation.bind(("127.0.0.1", 0))
            port = reservation.getsockname()[1]
        env.update({
            "SCCACHE_SERVER_PORT": str(port),
            "SCCACHE_DIR": str(work / "cache"),
            "SCCACHE_CONF": str(root / "isolated-sccache.toml"),
            "SCCACHE_C_CUSTOM_CACHE_BUSTER": "1",
            "SCCACHE_IDLE_TIMEOUT": "120",
        })
        profile = work / "profile.profdata"
        source = root / "cache_probe.cpp"
        base_args = [str(clang), "--target=x86_64-pc-windows-msvc",
                     "/c", "/nologo", "/O2", "/Brepro", str(source), "/Foprobe.obj"]
        started = False
        try:
            run([cache, "--start-server"], "start")
            started = True
            run([cache, "--show-stats"], "readiness")
            results = {}
            for mode, prefix in (("bare", ""), ("wrapped", "-clang:"), ("extra-file", "")):
                if mode == "extra-file":
                    env["SCCACHE_EXTRAFILES"] = str(profile)
                run([cache, "--zero-stats"], f"{mode}-zero")
                command = [str(cache), *base_args, f"{prefix}-fprofile-instr-use={profile}"]
                for variant in ("parent", "try"):
                    shutil.copyfile(profiles / f"{variant}-llvm-pgo.profdata", profile)
                    run(command, f"{mode}-{variant}")
                stats = run([cache, "--show-stats"], f"{mode}-stats")
                counts = {
                    key: int(re.search(rf"^{label}\s+(\d+)\s*$", stats.stdout, re.MULTILINE)[1])
                    for key, label in (("hits", "Cache hits"), ("misses", "Cache misses"))
                }
                results[mode] = counts
                if mode == "bare":
                    assert counts == {"hits": 1, "misses": 1}, counts
                    shutil.copyfile(root / "invalid-profile.profdata", profile)
                    cached = run(command, "bare-invalid-cached", success=False)
                    assert "profile" in cached.stderr.lower()
                    direct = run(command[1:], "bare-invalid-direct", success=False)
                    assert "profile" in direct.stderr.lower()
                    shutil.copyfile(profiles / "try-llvm-pgo.profdata", profile)
                    env["SCCACHE_C_CUSTOM_CACHE_BUSTER"] = hashlib.sha256(profile.read_bytes()).hexdigest()
                    run([cache, "--zero-stats"], "hash-buster-zero")
                    run(command, "hash-buster-try")
                    refreshed = run([cache, "--show-stats"], "hash-buster-stats")
                    assert re.search(r"^Cache misses\s+1\s*$", refreshed.stdout, re.MULTILINE)
                    assert re.search(r"^Cache hits\s+0\s*$", refreshed.stdout, re.MULTILINE)
                    results["hash_buster"] = {"hits": 0, "misses": 1}
                    env["SCCACHE_C_CUSTOM_CACHE_BUSTER"] = "1"
                else:
                    assert counts == {"hits": 0, "misses": 2}, counts
            result = {
                "confirmed": True, "results": results,
                "invalid_profile_rejected_both_cached_and_direct": True,
                "sccache_sha256": hashlib.sha256(cache.read_bytes()).hexdigest(),
                "clang_version": run([clang, "--version"], "clang-version").stdout,
                "compiler_scope": "Local Clang 23.1.4 targeting x64; producer used Clang 22.1.8. Exact producer sccache 0.10.0 binary and actual parent/try profiles are used.",
                "records_directory": str(output),
                "conclusion": "The bare LLVM profile-use flag does not invalidate sccache 0.10.0 MSVC entries when profile contents change.",
            }
            (root / "reproduction.json").write_text(json.dumps(result, indent=2) + "\n")
            print(json.dumps(result, indent=2))
        finally:
            if started:
                run([cache, "--stop-server"], "stop")
                with socket.socket() as check:
                    check.settimeout(2)
                    assert check.connect_ex(("127.0.0.1", port)) != 0, "Isolated cache server did not stop"
            (output / "commands.json").write_text(json.dumps(records, indent=2) + "\n")

if __name__ == "__main__":
    main()
