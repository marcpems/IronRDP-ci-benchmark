import copy
import json
import os
from pathlib import Path
import tempfile
import subprocess
import tomllib
import unittest
import zipfile
from unittest.mock import patch

from msvc_experiment import PHASES, audit_cmake_tools, audit_runtime_link, audit_runtime_modules, clang_profile_preflight, cmake_toolchain, configuration, equivalent_tools, execute, preserve_training_compiler, restore_completed_build, train, verify_profiles
from build_arm_compilers import digest


class ConfigurationTests(unittest.TestCase):
    def test_execute_propagates_resource_limit_without_changing_existing_default(self):
        with patch("msvc_experiment.telemetry_executables", return_value=[]), \
                patch("msvc_experiment.measure", return_value={
                    "exit_code": 0, "wall_seconds": 1, "cpu_seconds": 1,
                }) as measure, patch("msvc_experiment.save"):
            for env, override, expected in (({}, None, 4), ({"MATCHED_BUILD_CORES": "64"}, None, 64),
                                            ({"MATCHED_BUILD_CORES": "64"}, 8, 8)):
                execute(["build"], Path("."), env, Path("."), "fixture", cores=override)
                self.assertEqual(measure.call_args.args[3], expected)
            with self.assertRaises(ValueError):
                execute(["build"], Path("."), {"MATCHED_BUILD_CORES": "0"}, Path("."), "fixture")
    def test_pdb_runtime_audit_requires_both_modules_from_expected_library(self):
        library = r"C:\Pinned Clang\lib\clang_rt.profile-aarch64.lib"
        text = "\n".join(
            f"Mod {i} | `lib\\profile\\{name}.c.obj`: \nObj: `{library}`: \n"
            for i, name in enumerate(("InstrProfilingMerge", "InstrProfilingPlatformWindows")))
        audit_runtime_modules(text, library)
        for invalid in (text.replace("Pinned Clang", "Other Clang"),
                        text.replace("InstrProfilingMerge", "Missing"), ""):
            with self.assertRaises(RuntimeError):
                audit_runtime_modules(invalid, library)

    def test_resume_requires_completed_matching_stage2(self):
        for corrupt in (False, True):
            with self.subTest(corrupt=corrupt), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                capture, source, output = root / "capture", root / "source", root / "output"
                capture.mkdir()
                source.mkdir()
                output.mkdir()
                metadata = {key: "same" for key in ("phase", "host", "rust_sha", "llvm_sha", "perf_sha",
                            "profiling_runtime_sources", "bootstrap_linker_source_sha256")}
                metadata.update(tools={"msvc": "m", "sdk": "s", "files": {}}, run_id="old", attempt="1")
                (capture / "started.json").write_text(json.dumps(metadata))
                (capture / "build.json").write_text(json.dumps({"exit_code": 1 if corrupt else 0}))
                archive = capture / "instrumented-diagnostic.zip"
                with zipfile.ZipFile(archive, "w") as package:
                    package.writestr("sysroot/bin/rustc.exe", b"rustc")
                    package.writestr("training-tools/cargo.exe", b"cargo")
                (capture / "instrumented-diagnostic.json").write_text(json.dumps({
                    "stage": "stage2", "archive_sha256": digest(archive)}))
                for directory in (capture, output):
                    (directory / "rustc-pgo.profdata").write_bytes(b"profile")
                for name in ("build.stdout", "build.stderr", "CMakeCache.txt", "lld-CMakeCache.txt"):
                    (capture / name).write_text("fixture")
                for name in ("clang-profiling-runtime.json", "clang-runtime-rebuild.json"):
                    (capture / name).write_text("{}")

                def stage0(command, *args, **kwargs):
                    self.assertEqual(command[-2:], ["build", "--help"])
                    cargo = source / "build/host/stage0/bin/cargo.exe"
                    cargo.parent.mkdir(parents=True)
                    cargo.write_bytes(b"cargo")

                with patch("msvc_experiment.execute", side_effect=stage0):
                    if corrupt:
                        with self.assertRaisesRegex(RuntimeError, "verified completed"):
                            restore_completed_build(capture, source, output, "host", {}, metadata)
                    else:
                        restore_completed_build(capture, source, output, "host", {}, metadata)
                        self.assertTrue((source / "build/host/stage2/bin/rustc.exe").exists())
                        self.assertEqual(metadata["compiler_build_run"], "old")

    def test_runtime_audit_requires_loaded_library_not_search_path(self):
        expected = r"C:\Pinned Clang\lib\clang_rt.profile-aarch64.lib"
        members = ("Loaded clang_rt.profile-aarch64.lib(InstrProfilingMerge.c.obj)\n"
                   "Loaded clang_rt.profile-aarch64.lib(InstrProfilingPlatformWindows.c.obj)")
        audit_runtime_link(f"Searching {expected}:\n{members}", expected)
        for log in (f"/LIBPATH:{expected}", f"Searching {expected}:",
                    f"Searching C:\\Other\\clang_rt.profile-aarch64.lib:\n{members}"):
            with self.assertRaisesRegex(RuntimeError, "profiling runtime"):
                audit_runtime_link(log, expected)

    def test_stage1_capture_does_not_require_unbuilt_training_tools(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, output = Path(tmp) / "source", Path(tmp) / "output"
            output.mkdir()
            for path in (source / "build/host/stage1/bin/rustc.exe",
                         source / "build/host/stage0/bin/cargo.exe",
                         *(source / name for name in ("COPYRIGHT", "LICENSE-MIT", "LICENSE-APACHE"))):
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"fixture")
            preserve_training_compiler(source, output, "host", stage_name="stage1",
                                       include_training_tools=False)
            metadata = json.loads((output / "instrumented-diagnostic.json").read_text())
            self.assertEqual(metadata["stage"], "stage1")
            self.assertTrue(metadata["diagnostic_only"])
            with zipfile.ZipFile(output / "instrumented-diagnostic.zip") as archive:
                self.assertIn("sysroot/bin/rustc.exe", archive.namelist())
                self.assertNotIn("training-tools/collector.exe", archive.namelist())

    def test_clang_runtime_preflight_uses_matching_runtime_and_microsoft_linker(self):
        for host, suffix in (("aarch64-pc-windows-msvc", "aarch64"),
                             ("x86_64-pc-windows-msvc", "x86_64")):
            for fail_merge in (False, True):
                with self.subTest(host=host, fail_merge=fail_merge), tempfile.TemporaryDirectory() as tmp:
                    output = Path(tmp)
                    resource = output / "resource"
                    runtime = resource / "lib/windows" / f"clang_rt.profile-{suffix}.lib"
                    runtime.parent.mkdir(parents=True)
                    runtime.write_bytes(b"runtime")
                    calls = []

                    def execute(command, cwd, env, directory, name, **kwargs):
                        calls.append((name, command))
                        if name == "clang-profile-run-0":
                            (cwd / "raw/shared_123.profraw").touch()
                        if name == "clang-profile-merge" and fail_merge:
                            raise RuntimeError("malformed profile")

                    counters = ("main:\n Block counts: [800, 8]\n [0, bump, 800]\n"
                                "bump:\n Block counts: [800]\n")
                    with patch("msvc_experiment.subprocess.check_output",
                               side_effect=[str(resource), counters]), \
                         patch("msvc_experiment.execute", side_effect=execute):
                        arguments = (output, output / "clang", {},
                                     {"files": {"link.exe": {"path": "native-link.exe"}}}, host)
                        if fail_merge:
                            with self.assertRaisesRegex(RuntimeError, "malformed profile"):
                                clang_profile_preflight(*arguments)
                        else:
                            provenance = clang_profile_preflight(*arguments)
                            self.assertEqual(provenance["sha256"], digest(runtime))
                    link = dict(calls)["clang-profile-link"]
                    self.assertEqual(link[0], "native-link.exe")
                    self.assertIn(runtime, link)
                    self.assertEqual(sum(name.startswith("clang-profile-run-") for name, _ in calls), 8)
                    self.assertEqual(calls[-1][1][0], output / "clang/llvm-profdata.exe")

    def test_failed_training_archive_is_explicitly_diagnostic(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, output = Path(tmp) / "source", Path(tmp) / "output"
            for path in (source / "build/host/stage2/bin/rustc.exe",
                         source / "build/host/stage0/bin/cargo.exe",
                         output / "training/target/debug/collector.exe",
                         output / "training/target/debug/rustc-fake.exe",
                         *(source / name for name in ("COPYRIGHT", "LICENSE-MIT", "LICENSE-APACHE"))):
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"fixture")
            rustlib = source / "build/host/stage2/lib/rustlib"
            rustlib.mkdir(parents=True)
            if os.name == "nt":
                subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command",
                                f"New-Item -ItemType Junction -Path '{rustlib / 'src'}' "
                                f"-Target '{source}' | Out-Null"], check=True)
            else:
                (rustlib / "src").symlink_to(source, target_is_directory=True)
            preserve_training_compiler(source, output, "host")
            metadata = json.loads((output / "instrumented-diagnostic.json").read_text())
            self.assertTrue(metadata["diagnostic_only"])
            self.assertEqual(metadata["archive_sha256"], digest(output / "instrumented-diagnostic.zip"))
            with zipfile.ZipFile(output / "instrumented-diagnostic.zip") as archive:
                self.assertIn("sysroot/bin/rustc.exe", archive.namelist())
                self.assertIn("training-tools/rustc-fake.exe", archive.namelist())
                self.assertFalse(any(name.startswith("sysroot/lib/rustlib/src/") for name in archive.namelist()))
            self.assertFalse((output / "metadata.json").exists())
            self.assertFalse((output / "compiler.zip").exists())
            self.assertFalse((output / "instrumented-diagnostic.partial").exists())

    def test_training_builds_and_requires_all_collector_binaries(self):
        for provide_wrapper in (False, True):
            with self.subTest(provide_wrapper=provide_wrapper), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                source, output = root / "source", root / "output"
                fixture = source / "src/tools/rustc-perf/collector/compile-benchmarks/token-stream-stress"
                fixture.mkdir(parents=True)
                (fixture / "Cargo.lock").write_text('[[package]]\nname="token-stream-stress"\nversion="0.0.0"\n')
                output.mkdir()
                stages = []

                def execute(command, cwd, env, directory, name, **kwargs):
                    stages.append(name)
                    if name == "training-tools":
                        self.assertEqual(command[1:], ["build", "--locked", "-p", "collector", "--bins"])
                        binaries = cwd / "target/debug"
                        binaries.mkdir(parents=True)
                        (binaries / "collector.exe").touch()
                        if provide_wrapper:
                            (binaries / "rustc-fake.exe").touch()
                    if name == "training":
                        raise RuntimeError("training reached")

                message = "training reached" if provide_wrapper else "Missing training executable"
                with patch("msvc_experiment.execute", side_effect=execute), \
                     patch("msvc_experiment.training_crates", return_value=["token-stream-stress"]):
                    with self.assertRaisesRegex(RuntimeError, message):
                        train(source, output, "host", {}, False, root / "clang")
                self.assertEqual("training" in stages, provide_wrapper)

    def test_cmake_audit_rejects_a_different_linker(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            tools = {}
            lines = []
            for variable, name in (("CMAKE_LINKER", "link.exe"), ("CMAKE_AR", "lib.exe"),
                                   ("CMAKE_CXX_COMPILER", "clang-cl.exe")):
                binary = root / name
                binary.write_bytes(name.encode())
                tools[name] = {"sha256": digest(binary)}
                lines.append(f"{variable}:FILEPATH={binary.as_posix()}")
            cache = root / "CMakeCache.txt"
            cache.write_text("\n".join(lines))
            audit_cmake_tools(cache, {"files": tools})
            (root / "link.exe").write_bytes(b"different linker")
            with self.assertRaisesRegex(RuntimeError, "expected pinned link.exe"):
                audit_cmake_tools(cache, {"files": tools})

    def test_cmake_toolchain_pins_native_tools_with_spaces(self):
        with tempfile.TemporaryDirectory() as tmp:
            tools = {"files": {name: {"path": f"C:/Program Files/MSVC/{name}"}
                               for name in ("link.exe", "lib.exe")}}
            text = cmake_toolchain(Path(tmp), tools).read_text()
            self.assertIn('set(CMAKE_LINKER "C:/Program Files/MSVC/link.exe" CACHE FILEPATH "" FORCE)', text)
            self.assertIn('set(CMAKE_AR "C:/Program Files/MSVC/lib.exe" CACHE FILEPATH "" FORCE)', text)

    def test_only_rust_lto_differs_between_pgo_variants(self):
        for host in ("x86_64-pc-windows-msvc", "aarch64-pc-windows-msvc"):
            configs = {}
            for phase in PHASES:
                config = tomllib.loads(configuration(
                    host, Path("C:/clang"), Path("C:/vs/link.exe"),
                    Path("C:/vs/lib.exe"), phase, Path("C:/profiles")))
                configs[phase] = config
                self.assertFalse(config["llvm"]["thin-lto"])
                self.assertFalse(config["llvm"]["link-shared"])
                self.assertEqual(config["target"][host]["linker"], "link.exe")
                self.assertTrue(config["target"][host]["ar"].endswith("/lib.exe"))
                self.assertEqual(config["target"][host]["rustflags"],
                                 ["-Clink-arg=/VERBOSE", "-Wlinker-messages"] if phase == "llvm-profile" else [])
                self.assertEqual(config["build"]["host"], [host])
                self.assertTrue(config["build"]["profiler"])
                self.assertFalse(config["target"]["wasm32-unknown-unknown"]["profiler"])
            treatment = configs["pgo-rust-thin"]
            self.assertEqual(treatment["rust"]["lto"], "thin")
            treatment["rust"]["lto"] = "thin-local"
            self.assertEqual(treatment, configs["pgo"])
            self.assertEqual(configs["baseline"]["pgo"], {"rustc": {}, "llvm": {}})
            self.assertIn("generate", configs["rustc-profile"]["pgo"]["rustc"])
            self.assertIn("generate", configs["llvm-profile"]["pgo"]["llvm"])
            self.assertIn("use", configs["llvm-profile"]["pgo"]["rustc"])

    def test_bootstrap_linker_flag_has_no_space_separated_path(self):
        config = tomllib.loads(configuration(
            "x86_64-pc-windows-msvc", Path("D:/clang"),
            Path("C:/Program Files/Microsoft Visual Studio/link.exe"),
            Path("C:/Program Files/Microsoft Visual Studio/lib.exe"),
            "baseline", Path("D:/profiles")))
        self.assertEqual(config["target"]["x86_64-pc-windows-msvc"]["linker"], "link.exe")

    def test_tool_comparison_ignores_install_location_not_binary(self):
        left = {"msvc": "v1", "sdk": "s1", "files": {"link.exe": {"path": "a", "sha256": "hash"}}}
        right = copy.deepcopy(left)
        right["files"]["link.exe"]["path"] = "b"
        self.assertTrue(equivalent_tools(left, right))
        right["files"]["link.exe"]["sha256"] = "other"
        self.assertFalse(equivalent_tools(left, right))

    def test_profiles_require_matching_source_tools_phase_and_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            profile = root / "rustc-pgo.profdata"
            profile.write_bytes(b"profile")
            tools = {"msvc": "v1", "sdk": "s1", "files": {}}
            metadata = {"phase": "rustc-profile", "rust_sha": "source", "host": "host",
                        "tools": tools, "profiles": {profile.name: digest(profile)}}
            (root / "metadata.json").write_text(json.dumps(metadata))
            verify_profiles(root, "llvm-profile", tools, "source", "host")
            for phase, source in (("pgo", "source"), ("llvm-profile", "wrong")):
                with self.assertRaises(RuntimeError):
                    verify_profiles(root, phase, tools, source, "host")
            profile.write_bytes(b"modified")
            with self.assertRaises(RuntimeError):
                verify_profiles(root, "llvm-profile", tools, "source", "host")


if __name__ == "__main__":
    unittest.main()
