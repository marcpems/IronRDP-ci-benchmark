import json
from pathlib import Path
import tempfile
import tomllib
import unittest
from unittest.mock import patch

import matched_release as release


class MatchedReleaseTests(unittest.TestCase):
    def test_hosted_opt_in_preserves_exact_four_cpu_matched_configuration(self):
        host = "x86_64-pc-windows-msvc"
        with patch.dict(release.os.environ, {
            "RELEASE_MACHINE_CLASS": "self-hosted-x64",
            "RELEASE_SCALING_STUDY": release.SCALING_STUDY, "RELEASE_BUILD_CORES": "4",
        }, clear=True):
            expected = release.configuration(host, Path("C:/clang/bin"), Path("C:/VS/lib.exe"),
                                             release.SCALING_VARIANT)
        with patch.dict(release.os.environ, {
            "RELEASE_MACHINE_CLASS": "github-hosted", "RUNNER_ENVIRONMENT": "github-hosted",
            "RELEASE_HOSTED_BASELINE": release.HOSTED_BASELINE,
        }, clear=True):
            self.assertTrue(release.hosted_baseline())
            self.assertEqual(release.build_cores(), 4)
            release.validate_recipe(host, release.SCALING_VARIANT)
            self.assertEqual(release.configuration(
                host, Path("C:/clang/bin"), Path("C:/VS/lib.exe"), release.SCALING_VARIANT), expected)
            for other_host, variant in ((host, "msvc-pgo"), (host, "baseline"),
                                        ("aarch64-pc-windows-msvc", release.SCALING_VARIANT)):
                with self.assertRaisesRegex(RuntimeError, "hosted baseline requires"):
                    release.validate_recipe(other_host, variant)

    def test_hosted_opt_in_cannot_enable_selfhost_or_scaling_overrides(self):
        base = {
            "RELEASE_MACHINE_CLASS": "github-hosted", "RUNNER_ENVIRONMENT": "github-hosted",
            "RELEASE_HOSTED_BASELINE": release.HOSTED_BASELINE,
        }
        for override in (
            {"RELEASE_HOSTED_BASELINE": ""}, {"RELEASE_HOSTED_BASELINE": "unknown"},
            {"RELEASE_MACHINE_CLASS": "self-hosted-x64"},
            {"RUNNER_ENVIRONMENT": "self-hosted"}, {"RUNNER_ENVIRONMENT": ""},
            {"RELEASE_BUILD_CORES": "4"}, {"RELEASE_BUILD_CORES": "16"},
            {"RELEASE_SCALING_STUDY": release.SCALING_STUDY},
            {"RELEASE_SCALING_STUDY": ""},
        ):
            with self.subTest(override=override), patch.dict(release.os.environ, {**base, **override}, clear=True):
                with self.assertRaisesRegex(RuntimeError, "hosted-only"):
                    release.build_cores()
        with patch.dict(release.os.environ, base, clear=True), \
                patch.object(release.os, "name", "nt"), \
                patch.object(release.platform, "machine", return_value="AMD64"):
            for count in (2, 8, 16):
                with patch.object(release.os, "cpu_count", return_value=count):
                    with self.assertRaisesRegex(RuntimeError, "four-logical"):
                        release.validate_runner("x86_64-pc-windows-msvc")
            with patch.object(release.os, "cpu_count", return_value=4):
                release.validate_runner("x86_64-pc-windows-msvc")
        with patch.dict(release.os.environ, base, clear=True), patch.object(release, "validate_runner"):
            for kwargs in ({"full_distribution": False}, {"rust_revision": "diagnostic-parent"}):
                with self.assertRaisesRegex(RuntimeError, "pinned full-production"):
                    release.prepare(Path("C:/mr/r"), Path("C:/mr/l"), Path("C:/mr/e"),
                                    "x86_64-pc-windows-msvc", release.SCALING_VARIANT, **kwargs)

    def test_hosted_deadline_keeps_ten_minutes_for_evidence(self):
        with patch.dict(release.os.environ, {
            "RELEASE_MACHINE_CLASS": "github-hosted", "RELEASE_JOB_STARTED": "100",
        }, clear=True), patch.object(release.time, "time", return_value=100 + 340 * 60), \
                patch.object(release, "execute") as execute, patch.object(release, "save"):
            release.run(["build"], Path("."), {}, Path("."), "full-dist")
            self.assertEqual(execute.call_args.kwargs["timeout"], 10 * 60)
            with patch.object(release.time, "time", return_value=100 + 350 * 60):
                with self.assertRaisesRegex(TimeoutError, "350-minute"):
                    release.run(["build"], Path("."), {}, Path("."), "full-dist")

    def test_scaling_keeps_microsoft_tools_and_enables_only_rust_thinlto(self):
        for machine, allocations in (("x64", (4, 16)), ("arm64", (4, 8, 16)),
                                     ("arm64-highcore", (4, 16, 32))):
            host = "x86_64-pc-windows-msvc" if machine == "x64" else "aarch64-pc-windows-msvc"
            for cores in allocations:
                with self.subTest(machine=machine, cores=cores), patch.dict(release.os.environ, {
                    "RELEASE_MACHINE_CLASS": f"self-hosted-{machine}",
                    "RELEASE_SCALING_STUDY": release.SCALING_STUDY,
                    "RELEASE_BUILD_CORES": str(cores),
                }):
                    self.assertEqual(release.build_cores(), cores)
                    config = tomllib.loads(release.configuration(
                        host, Path("C:/clang/bin"), Path("C:/VS/lib.exe"), release.SCALING_VARIANT))
                    self.assertEqual(config["build"]["jobs"], cores)
                    self.assertTrue(config["build"]["extended"])
                    self.assertTrue(config["build"]["docs"])
                    self.assertEqual(config["rust"]["lto"], "thin")
                    self.assertFalse(config["llvm"]["thin-lto"])
                    self.assertEqual(config["llvm"]["link-jobs"], 1)
                    self.assertEqual(config["target"][host]["linker"], "link.exe")
                    self.assertEqual(config["target"][host]["ar"], "C:/VS/lib.exe")

    def test_scaling_cpu_overrides_fail_closed(self):
        for machine, study, cores in (
            ("github-hosted", release.SCALING_STUDY, "16"),
            ("self-hosted-x64", "unknown", "16"),
            ("self-hosted-x64", release.SCALING_STUDY, "32"),
            ("self-hosted-x64", release.SCALING_STUDY, "8"),
            ("self-hosted-arm64-highcore", release.SCALING_STUDY, "8"),
            ("self-hosted-arm64", release.SCALING_STUDY, "0"),
            ("self-hosted-arm64-highcore", release.SCALING_STUDY, "64"),
        ):
            with self.subTest(machine=machine, study=study, cores=cores), patch.dict(release.os.environ, {
                "RELEASE_MACHINE_CLASS": machine, "RELEASE_SCALING_STUDY": study,
                "RELEASE_BUILD_CORES": cores,
            }):
                with self.assertRaises(RuntimeError):
                    release.build_cores()
        with patch.dict(release.os.environ, {
            "RELEASE_MACHINE_CLASS": "self-hosted-x64",
            "RELEASE_SCALING_STUDY": release.SCALING_STUDY, "RELEASE_BUILD_CORES": "16",
            "RUNNER_ENVIRONMENT": "self-hosted", "RUNNER_NAME": "MARCPE-TEST01-X64",
        }), patch.object(release.os, "name", "nt"), \
                patch.object(release.os, "cpu_count", return_value=8), \
                patch.object(release.platform, "machine", return_value="AMD64"):
            with self.assertRaisesRegex(RuntimeError, "unexpected self-hosted"):
                release.validate_runner("x86_64-pc-windows-msvc")

    def test_scaling_recipe_cannot_silently_enter_old_study(self):
        with patch.object(release, "validate_runner"):
            with self.assertRaisesRegex(RuntimeError, "distinct"):
                release.prepare(Path("C:/mr/r"), Path("C:/mr/l"), Path("C:/mr/e"),
                                "aarch64-pc-windows-msvc", release.SCALING_VARIANT)
            with patch.dict(release.os.environ, {"RELEASE_SCALING_STUDY": release.SCALING_STUDY}):
                with self.assertRaisesRegex(RuntimeError, "distinct"):
                    release.prepare(Path("C:/mr/r"), Path("C:/mr/l"), Path("C:/mr/e"),
                                    "aarch64-pc-windows-msvc", "msvc-pgo")

    def test_rust_lto_audit_distinguishes_thin_from_thin_local(self):
        flags = "-Cprofile-use=profile -Zdylib-lto -Clto=thin -Clinker=link.exe"
        self.assertTrue(release.audit_rust_flags([flags], pgo=True, thin=True)["thin"])
        for changed in (flags.replace("lto=thin", "lto=thin-local"),
                        flags.replace("linker=link.exe", "linker=lld-link.exe"),
                        flags.replace("-Cprofile-use=profile", "")):
            with self.subTest(changed=changed), self.assertRaises(RuntimeError):
                release.audit_rust_flags([changed], pgo=True, thin=True)

    def test_highcore_is_a_separate_native_arm64_resource_class(self):
        with patch.dict(release.os.environ, {
            "RELEASE_MACHINE_CLASS": "self-hosted-arm64-highcore",
            "RUNNER_ENVIRONMENT": "self-hosted", "RUNNER_NAME": "GB300-Arm64",
        }), patch.object(release.os, "name", "nt"), \
                patch.object(release.os, "cpu_count", return_value=72), \
                patch.object(release.platform, "machine", return_value="ARM64"):
            release.validate_runner("aarch64-pc-windows-msvc")
            self.assertEqual(release.build_cores(), 64)
            for variant in release.VARIANTS:
                config = tomllib.loads(release.configuration(
                    "aarch64-pc-windows-msvc", Path("C:/clang/bin"), Path("C:/VS/lib.exe"), variant))
                self.assertEqual(config["build"]["jobs"], 64)
                self.assertEqual(config["llvm"]["link-jobs"], 2)
                self.assertIn("arm64ec-pc-windows-msvc", config["build"]["target"])
                self.assertTrue(config["build"]["docs"])
            with patch.dict(release.os.environ, {"RUNNER_NAME": "MARCPE-D4-Arm64"}):
                with self.assertRaisesRegex(RuntimeError, "unexpected self-hosted"):
                    release.validate_runner("aarch64-pc-windows-msvc")
            with patch.object(release.os, "cpu_count", return_value=32):
                with self.assertRaisesRegex(RuntimeError, "unexpected self-hosted"):
                    release.validate_runner("aarch64-pc-windows-msvc")
            with self.assertRaisesRegex(RuntimeError, "native Windows"):
                release.validate_runner("x86_64-pc-windows-msvc")

    def test_x64_selfhost_requires_matching_identity_architecture_and_capacity(self):
        with patch.object(release.os, "name", "nt"), \
                patch.object(release.os, "cpu_count", return_value=8), \
                patch.object(release.platform, "machine", return_value="AMD64"), \
                patch.dict(release.os.environ, {
                    "RELEASE_MACHINE_CLASS": "self-hosted-x64",
                    "RUNNER_ENVIRONMENT": "self-hosted", "RUNNER_NAME": "MARCPE-TEST01-X64",
                }):
            host = "x86_64-pc-windows-msvc"
            release.validate_runner(host)
            for override in ({"RUNNER_NAME": "MARCPE-D4-Arm64"},
                             {"RUNNER_ENVIRONMENT": "github-hosted"},
                             {"RELEASE_MACHINE_CLASS": "self-hosted-arm64"},
                             {"RELEASE_MACHINE_CLASS": "github-hosted"}):
                with self.subTest(override=override), patch.dict(release.os.environ, override):
                    with self.assertRaises(RuntimeError):
                        release.validate_runner(host)
            with patch.object(release.os, "cpu_count", return_value=2):
                with self.assertRaises(RuntimeError):
                    release.validate_runner(host)
            with patch.object(release.platform, "machine", return_value="ARM64"):
                with self.assertRaisesRegex(RuntimeError, "native Windows"):
                    release.validate_runner(host)

    def test_selfhost_runner_is_explicit_and_cannot_impersonate_hosted(self):
        with patch.object(release.os, "name", "nt"), \
                patch.object(release.os, "cpu_count", return_value=12), \
                patch.object(release.platform, "machine", return_value="ARM64"), \
                patch.dict(release.os.environ, {
                    "RELEASE_MACHINE_CLASS": "self-hosted-arm64",
                    "RUNNER_ENVIRONMENT": "self-hosted", "RUNNER_NAME": "MARCPE-D4-Arm64",
                }):
            release.validate_runner("aarch64-pc-windows-msvc")
            with patch.dict(release.os.environ, {"RUNNER_NAME": "other"}):
                with self.assertRaisesRegex(RuntimeError, "unexpected self-hosted"):
                    release.validate_runner("aarch64-pc-windows-msvc")
            with patch.dict(release.os.environ, {"RELEASE_MACHINE_CLASS": "github-hosted"}), \
                    patch.object(release.os, "cpu_count", return_value=4):
                with self.assertRaisesRegex(RuntimeError, "GitHub-hosted"):
                    release.validate_runner("aarch64-pc-windows-msvc")

    def test_selfhost_deadline_reserves_upload_time(self):
        for architecture in ("arm64", "x64", "arm64-highcore"):
            with self.subTest(architecture=architecture):
                self.check_selfhost_deadline(architecture)

    def check_selfhost_deadline(self, architecture):
        with patch.dict(release.os.environ, {
            "RELEASE_JOB_STARTED": "100", "RELEASE_MACHINE_CLASS": f"self-hosted-{architecture}",
        }), patch.object(release.time, "time", return_value=100 + 400 * 60), \
                patch.object(release, "execute") as execute, patch.object(release, "save"):
            release.run(["build"], Path("."), {}, Path("."), "full-dist")
            self.assertEqual(execute.call_args.kwargs["timeout"], 1030 * 60)
            with patch.object(release.time, "time", return_value=100 + 1430 * 60):
                with self.assertRaisesRegex(TimeoutError, "1430-minute"):
                    release.run(["build"], Path("."), {}, Path("."), "full-dist")

    def test_preparation_checks_declared_source_before_building(self):
        roots = tuple(Path(f"C:/mr/{name}") for name in ("r", "l", "e"))
        for revision in (release.RUST, "diagnostic-parent"):
            with patch.object(release.os, "name", "nt"), \
                    patch.object(release.os, "cpu_count", return_value=4), \
                    patch.object(release.platform, "machine", return_value="ARM64"), \
                    patch.object(release.subprocess, "check_output",
                                 side_effect=[revision, "wrong-llvm-revision"]) as checkout:
                kwargs = {} if revision == release.RUST else {"rust_revision": revision}
                with self.assertRaisesRegex(RuntimeError, "llvm-project"):
                    release.prepare(*roots, "aarch64-pc-windows-msvc", "msvc-pgo", **kwargs)
                self.assertEqual(checkout.call_count, 2)

    def test_qualification_uses_upstream_build_root_and_restores_config(self):
        host = "aarch64-pc-windows-msvc"
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source, output = root / "rust", root / "evidence"
            source.mkdir()
            output.mkdir()
            original = b'profile = "dist"\n'
            (source / "bootstrap.toml").write_bytes(original)
            llvm = source / "build" / host / "llvm/bin/llvm-config.exe"
            llvm.parent.mkdir(parents=True)
            llvm.write_bytes(b"fixture")
            unpacked = source / "build/unpacked-dist"

            def extract(command, check):
                self.assertTrue(check)
                self.assertEqual(command[:2], ["tar", "-xJf"])
                self.assertEqual(command[-1], unpacked)
                name = command[2].name.removesuffix(".tar.xz")
                relative = {
                    f"rustc-nightly-{host}": "rustc/bin/rustc.exe",
                    f"rust-std-nightly-{host}": f"rust-std-{host}/lib/rustlib/{host}/lib/std.rmeta",
                    f"cargo-nightly-{host}": "cargo/bin/cargo.exe",
                    "rust-src-nightly": "rust-src/lib/rustlib/src/rust/library/lib.rs",
                }[name]
                file = unpacked / name / relative
                file.parent.mkdir(parents=True, exist_ok=True)
                file.write_bytes(b"fixture")

            def fail_test(*args):
                config = tomllib.loads((source / "bootstrap.toml").read_text())
                compiler = Path(config["build"]["rustc"])
                self.assertTrue(compiler.is_relative_to(source / "build"))
                self.assertTrue(compiler.is_file())
                raise RuntimeError("test failure")

            with patch.object(release.subprocess, "run", side_effect=extract), \
                    patch.object(release, "run", side_effect=fail_test):
                with self.assertRaisesRegex(RuntimeError, "test failure"):
                    release.qualify_distribution(source, output, host, {})
            self.assertEqual((source / "bootstrap.toml").read_bytes(), original)
            self.assertFalse((output / "extracted").exists())

    def test_long_physical_roots_fail_before_expensive_builds(self):
        release.check_build_paths(Path("C:/mr/r"), Path("C:/mr/l"), Path("C:/mr/e"))
        with self.assertRaisesRegex(RuntimeError, "short physical build roots"):
            release.check_build_paths(Path("C:/a/IronRDP-ci-benchmark/rust-source"))

    def test_workflows_relocate_on_workspace_volume(self):
        workflows = Path(__file__).parents[1] / "workflows"
        for name in ("matched-release.yml", "matched-release-ironrdp.yml"):
            text = (workflows / name).read_text()
            self.assertIn("GetPathRoot($env:GITHUB_WORKSPACE)", text)
            self.assertIn("[System.IO.Directory]::Move", text)
            self.assertNotIn("$env:SystemDrive", text)

    def test_full_scope_and_only_declared_configuration_differences(self):
        for host in ("x86_64-pc-windows-msvc", "aarch64-pc-windows-msvc"):
            configs = {}
            for variant in release.VARIANTS:
                configs[variant] = tomllib.loads(release.configuration(
                    host, Path("C:/clang/bin"),
                    Path("C:/clang/bin/llvm-lib.exe" if variant == "llvm-pgo-thin" else "C:/VS/lib.exe"),
                    variant))
            self.assertEqual(configs["baseline"], configs["msvc-pgo"])
            base = configs["baseline"]
            self.assertTrue(base["build"]["extended"])
            self.assertTrue(base["build"]["docs"])
            self.assertTrue(base["rust"]["llvm-bitcode-linker"])
            self.assertFalse(base["llvm"]["thin-lto"])
            self.assertEqual(base["rust"]["lto"], "thin-local")
            self.assertFalse(base["llvm"]["download-ci-llvm"])
            self.assertEqual(base["build"]["jobs"], 4)
            llvm = configs["llvm-pgo-thin"]
            self.assertTrue(llvm["llvm"]["thin-lto"])
            self.assertEqual(llvm["rust"]["lto"], "thin")
            self.assertEqual(llvm["target"][host]["linker"], "lld-link.exe")
            self.assertEqual(base["target"][host]["linker"], "link.exe")
            self.assertEqual("arm64ec-pc-windows-msvc" in base["build"]["target"],
                             host.startswith("aarch64"))
            self.assertEqual(base["build"], llvm["build"])
            self.assertFalse(llvm["llvm"]["link-shared"])

    def test_manifest_rejects_compiler_only_and_missing_arm64ec(self):
        host = "aarch64-pc-windows-msvc"
        names = [f"{name}-nightly-{host}.{suffix}" for name, suffix in (
            ("rustc", "tar.xz"), ("rust-std", "tar.xz"), ("cargo", "tar.xz"),
            ("rust-docs", "tar.xz"), ("rustfmt", "tar.xz"), ("clippy", "tar.xz"),
            ("rust-analyzer", "tar.xz"), ("rust", "msi"))]
        names.append("rust-src-nightly.tar.xz")
        with self.assertRaisesRegex(RuntimeError, "arm64ec"):
            release.check_manifest([Path(name) for name in names], host)
        names.append("rust-std-nightly-arm64ec-pc-windows-msvc.tar.xz")
        release.check_manifest([Path(name) for name in names], host)
        with self.assertRaisesRegex(RuntimeError, "incomplete full distribution"):
            release.check_manifest([Path(names[0])], host)

    def test_deadline_is_global_and_never_reports_success(self):
        with patch.dict(release.os.environ, {"RELEASE_JOB_STARTED": "100"}), \
                patch.object(release.time, "time", return_value=100 + 350 * 60), \
                patch.object(release, "execute") as execute:
            with self.assertRaises(TimeoutError):
                release.run(["build"], Path("."), {}, Path("."), "full-dist")
            execute.assert_not_called()

    def test_protocol_does_not_transfer_old_results(self):
        protocol = json.loads((Path(__file__).parents[2] /
                               "ci-benchmark/matched-release/protocol.json").read_text())
        self.assertEqual(protocol["rust_sha"], release.RUST)
        self.assertEqual(protocol["variants"], list(release.VARIANTS))
        self.assertEqual(protocol["release_repetitions_per_cell"], 3)
        self.assertTrue(protocol["pilot_excluded"])
        self.assertIn("right-censored", protocol["timeouts"])


if __name__ == "__main__":
    unittest.main()
