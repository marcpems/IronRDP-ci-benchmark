set(CMAKE_LINKER "D:/ri/clang/bin/lld-link.exe" CACHE FILEPATH "" FORCE)
set(CMAKE_AR "D:/ri/clang/bin/llvm-lib.exe" CACHE FILEPATH "" FORCE)
