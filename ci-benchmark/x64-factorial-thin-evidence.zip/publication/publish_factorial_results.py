import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED

HARNESS = Path(r"D:\copilot\IronRDP-factorial-thin")
BASE = Path(r"D:\copilot\factorial-thin-evidence")
REPORT = Path(r"D:\copilot\IronRDP-matched-release\ci-benchmark")
STAGE = BASE / "qualified-20261102"
sys.path.insert(0, str(HARNESS / ".github/scripts"))
from x64_factorial_thin import ARMS, PROTOCOL, digest, file_manifest, read
from verify_x64_factorial_thin import verify
from msvc_experiment import equivalent_tools

head = subprocess.check_output(["git", "-C", str(HARNESS), "rev-parse", "HEAD"], text=True).strip()
if head != "486ab75de9853ba13f916cbb0a97dbe6c6d3fb2f":
    raise RuntimeError("Final verifier changed")
continuation = read(HARNESS / "ci-benchmark/x64-factorial-continuation.json")
sources = {
    "schema_version": 1, "protocol_sha256": digest(PROTOCOL),
    "reason": "Preserve successful VMs 1, 2, 4; replace only VM 3 after an untimed native test filename collision",
    "vms": {},
}
inputs = {}
for vm in range(1, 5):
    run = "41422268136" if vm == 3 else "41416787160"
    path = BASE / run / "artifacts" / f"factorial-consumer-{vm}"
    index = read(path / "index.json")
    if not index["complete"] or index["vm"] != vm or index["run_id"] != run:
        raise RuntimeError(f"VM {vm} not complete")
    sources["vms"][str(vm)] = {
        key: index[key] for key in ("run_id", "harness_sha", "attempt")
    }
    sources["vms"][str(vm)].update(
        index_sha256=digest(path / "index.json"),
        correctness_environment={"PUBLIC": r"C:\Users\Public", **({"RUST_TEST_THREADS": "1"} if vm == 3 else {})},
    )
    inputs[f"factorial-consumer-{vm}"] = path
for arm in ARMS:
    run = continuation["arms"][arm]["run_id"]
    inputs[f"factorial-{arm}-evidence"] = BASE / run / "artifacts" / f"factorial-{arm}-evidence"
    record = read(inputs[f"factorial-{arm}-evidence"] / "result.json")
    package = BASE / run / "artifacts" / f"factorial-{arm}-package"
    if read(package / "e/result.json") != record or digest(package / "package.zip") != record["archive_sha256"]:
        raise RuntimeError("Original compiler package changed")
    with ZipFile(package / "package.zip") as archive:
        if len(archive.namelist()) != len(set(archive.namelist())):
            raise RuntimeError("Duplicate compiler package members")
        actual = {}
        for member in archive.infolist():
            with archive.open(member) as stream:
                actual[member.filename] = hashlib.file_digest(stream, "sha256").hexdigest()
        if actual != record["files"]:
            raise RuntimeError("Original compiler contents changed")
STAGE.mkdir(exist_ok=True)
artifacts = STAGE / "artifacts"
for name, path in inputs.items():
    target = artifacts / name
    if target.exists():
        if file_manifest(target) != file_manifest(path):
            raise RuntimeError(f"Staged evidence changed: {name}")
    else:
        shutil.copytree(path, target)
result = verify(artifacts, "41422268136", head, 1, continuation, sources)
lock = subprocess.check_output(
    ["git", "-C", str(HARNESS), "show", f"{read(PROTOCOL)['source_sha']}:Cargo.lock"])
checkout_lock = lock.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
for vm in range(1, 5):
    root = artifacts / f"factorial-consumer-{vm}"
    index = read(root / "index.json")
    if index["workload_lock_sha256"] != hashlib.sha256(checkout_lock).hexdigest():
        raise RuntimeError("Consumer lock differs from the exact pinned CRLF checkout")
    if not equivalent_tools(index["tools"], index["compilers"]["baseline"]["tools"]):
        raise RuntimeError("Consumer native tools differ")
    meter = read(root / "meter-validation/self-test.json")
    if not (meter["busy_descendant"]["exit_code"] == meter["sleep"]["exit_code"] == 0
            and meter["busy_descendant"]["cpu_seconds"] >= 0.25
            and meter["sleep"]["cpu_seconds"] <= 0.2
            and meter["affinity"]["exit_code"] == 0 and meter["affinity"]["affinity"] == [0]):
        raise RuntimeError("Consumer CPU/affinity meter did not qualify")
(STAGE / "pinned-Cargo.lock").write_bytes(lock)
result["consumer_audit"] = {
    "lock_git_blob_sha256": hashlib.sha256(lock).hexdigest(),
    "lock_crlf_checkout_sha256": hashlib.sha256(checkout_lock).hexdigest(),
    "all_four_locks_match_pinned_crlf_checkout": True,
    "all_four_native_tools_match": True,
    "all_four_cpu_affinity_meters_pass": True,
}
result["analysis_harness_sha"] = head
result["limits"] = (
    "Four independent hosted consumer VMs; one producer per compiler arm. "
    "Shared baseline native stdlib and stage0 Cargo, LLD tools throughout. "
    "Compiler/sysroot isolation, not full-release or application-runtime qualification. "
    "VM 3 recovered with serialized correctness only; other VMs retained. "
    "VM-cluster bootstrap intervals do not include compiler build-to-build variance."
)
for name, value in (("x64-factorial-consumer-sources.json", sources),
                    ("x64-factorial-thin-results.json", result)):
    (REPORT / name).write_text(json.dumps(value, indent=2) + "\n")
files = {}
files["workload/pinned-Cargo.lock"] = STAGE / "pinned-Cargo.lock"
for path in artifacts.rglob("*"):
    if path.is_file():
        files[path.relative_to(STAGE).as_posix()] = path
for vm in (1, 3, 4):
    path = BASE / "41412682516/artifacts" / f"factorial-consumer-{vm}"
    for file in path.rglob("*"):
        if file.is_file():
            files[f"failures/powershell-probe/vm-{vm}/{file.relative_to(path).as_posix()}"] = file
path = BASE / "41416787160/artifacts/factorial-consumer-3"
for file in path.rglob("*"):
    if file.is_file():
        files[f"failures/parallel-correctness/{file.relative_to(path).as_posix()}"] = file
path = BASE / "41116552933/artifacts/factorial-both-thin-evidence"
for file in path.rglob("*"):
    if file.is_file():
        files[f"failures/producer-source-fetch/{file.relative_to(path).as_posix()}"] = file
files["failures/producer-source-fetch/job.log"] = BASE / "41116552933/failed-both-setup.log"
for name in ("x64-factorial-consumer-sources.json", "x64-factorial-thin-results.json"):
    files[name] = REPORT / name
for name in ("x64-factorial-thin.json", "x64-factorial-continuation.json", "x64-factorial-recovery.json",
             "x64-rust-thin-incremental.json"):
    files[f"harness/ci-benchmark/{name}"] = HARNESS / "ci-benchmark" / name
for file in (HARNESS / ".github/scripts").glob("*.py"):
    files[f"harness/.github/scripts/{file.name}"] = file
files["harness/.github/scripts/invoke_msvc_experiment.ps1"] = HARNESS / ".github/scripts/invoke_msvc_experiment.ps1"
for name in ("x64-factorial-thin.yml", "x64-factorial-both-recovery.yml",
             "x64-factorial-consumer-continuation.yml"):
    files[f"harness/.github/workflows/{name}"] = HARNESS / ".github/workflows" / name
files["publication/publish_factorial_results.py"] = Path(__file__)
manifest = {name: {"sha256": digest(path), "bytes": path.stat().st_size} for name, path in files.items()}
archive_path = REPORT / "x64-factorial-thin-evidence.zip"
with ZipFile(archive_path, "w", ZIP_DEFLATED, compresslevel=9) as archive:
    archive.writestr("manifest.json", json.dumps(manifest, indent=2))
    for name, path in files.items():
        archive.write(path, name)
with ZipFile(archive_path) as archive:
    if archive.testzip() is not None:
        raise RuntimeError("Evidence ZIP failed validation")
print(json.dumps(result["effects"], indent=2))
print("Evidence ZIP:", archive_path.stat().st_size, "bytes; SHA256", digest(archive_path))
