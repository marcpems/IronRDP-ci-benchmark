set(CMAKE_LINKER "C:/Program Files/Microsoft Visual Studio/2022/Enterprise/VC/Tools/MSVC/14.44.35207/bin/HostX64/x64/link.exe" CACHE FILEPATH "" FORCE)
set(CMAKE_AR "C:/Program Files/Microsoft Visual Studio/2022/Enterprise/VC/Tools/MSVC/14.44.35207/bin/HostX64/x64/lib.exe" CACHE FILEPATH "" FORCE)
