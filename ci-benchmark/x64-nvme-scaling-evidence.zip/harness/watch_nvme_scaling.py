import argparse
from datetime import datetime
import json
from pathlib import Path
import time

from watch_rust199 import REPO, gh, save


def verify_cell(root, workers, reference, run_id):
    results = list(root.rglob("result.json"))
    if len(results) != 1:
        raise RuntimeError(f"Expected one result for {workers} LP")
    evidence = results[0].parent
    result = json.loads(results[0].read_text())
    if (result.get("complete") is not True or result.get("build_workers") != workers
            or result.get("run_id") != run_id
            or result["compiler_cache_status"]["compiler_cache"] != "not enabled"
            or result["compiler_cache_status"]["hit_rate"] is not None):
        raise RuntimeError(f"Unqualified scaling cell: {workers}")
    if reference and reference["comparison_identity"] != result["comparison_identity"]:
        raise RuntimeError("Cross-cell source, tools, configuration or hardware changed")
    sections = json.loads((evidence / "pipeline-sections.json").read_text())
    required = {
        "Stage 1 (Rustc + rustdoc + cargo + clippy PGO)",
        "Stage 2 (LLVM PGO)", "Stage 5 (final build)", "Run tests",
    }
    if (sections["unfinished"] or any(row["status"] != "OK" for row in sections["completed"])
            or not required <= {row["name"] for row in sections["completed"]}):
        raise RuntimeError("Incomplete production or qualification")
    rows = {row["name"]: row["wall_seconds"] for row in sections["completed"]}
    if abs(result["production_seconds"] + rows["Run tests"] - result["production_and_tests_seconds"]) > 0.001:
        raise RuntimeError("Production/qualification arithmetic mismatch")
    commands = [json.loads((evidence / f"{name}.json").read_text())
                for name in ("build-opt-dist", "full-release")]
    lock = evidence / "training-lockfile.json"
    if lock.exists():
        commands.append(json.loads(lock.read_text()))
    if any(row["exit_code"] != 0 or row["affinity"] != list(range(workers)) for row in commands):
        raise RuntimeError("Failed measured command or incorrect inherited affinity")
    return result, {
        "workers": workers, "production_seconds": result["production_seconds"],
        "qualification_seconds": rows["Run tests"],
        "production_and_tests_seconds": result["production_and_tests_seconds"],
        "command_wall_seconds": sum(row["wall_seconds"] for row in commands),
        "command_cpu_seconds": sum(row["cpu_seconds"] for row in commands),
        "top_level_sections": {name: rows[name] for name in required},
        "compiler_cache_status": result["compiler_cache_status"],
        "profiles": result["profiles"],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--head", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    deadline, previous = time.monotonic() + 74 * 3600, None
    downloaded = set()
    for workers in (16, 8, 4):
        name = f"nvme-scaling-{workers}-evidence"
        existing = args.output / name
        if existing.exists():
            verify_cell(existing, workers, None, args.run_id)
            downloaded.add(name)
            print(f"Verified and retained existing {workers}-LP evidence", flush=True)
    while time.monotonic() < deadline:
        current = json.loads(gh("run", "view", args.run_id, "--repo", REPO,
                               "--json", "status,conclusion,jobs,url,headSha,createdAt,updatedAt"))
        if current["headSha"] != args.head:
            raise RuntimeError("Run changed harness revision")
        save(args.output / "progress.json", current)
        status = [(job["name"], job["status"], job["conclusion"],
                   [step["name"] for step in job["steps"] if step["status"] == "in_progress"])
                  for job in current["jobs"]]
        if status != previous:
            print(json.dumps(status), flush=True)
            previous = status
        completed = [job for job in current["jobs"] if job["status"] == "completed"]
        if completed:
            artifacts = json.loads(gh("api", f"repos/{REPO}/actions/runs/{args.run_id}/artifacts?per_page=100"))
            save(args.output / "artifacts.json", artifacts)
            for artifact in artifacts["artifacts"]:
                name = artifact["name"]
                if name.endswith("-evidence") and name not in downloaded:
                    gh("run", "download", args.run_id, "--repo", REPO, "--name", name,
                       "--dir", str(args.output / name))
                    downloaded.add(name)
                    print(f"Preserved {name}", flush=True)
        if current["status"] == "completed":
            save(args.output / "completion.json", current)
            if current["conclusion"] != "success":
                (args.output / "failed.log").write_text(
                    gh("run", "view", args.run_id, "--repo", REPO, "--log-failed"), encoding="utf-8")
                raise RuntimeError(f"NVMe scaling concluded {current['conclusion']}; retained partial evidence")
            reference, rows = None, []
            for workers in (16, 8, 4):
                result, row = verify_cell(args.output / f"nvme-scaling-{workers}-evidence",
                                          workers, reference, args.run_id)
                reference = reference or result
                jobs = [job for job in current["jobs"]
                        if job["name"].endswith(f"release on {workers} logical processors")]
                if len(jobs) != 1 or jobs[0]["conclusion"] != "success":
                    raise RuntimeError(f"Expected one qualified {workers}-LP job")
                job = jobs[0]
                row["whole_job_seconds"] = (
                    datetime.fromisoformat(job["completedAt"].replace("Z", "+00:00"))
                    - datetime.fromisoformat(job["startedAt"].replace("Z", "+00:00"))
                ).total_seconds()
                row["outside_production_and_tests_seconds"] = (
                    row["whole_job_seconds"] - row["production_and_tests_seconds"])
                row["job_url"] = job["url"]
                rows.append(row)
            save(args.output / "verified-summary.json", {
                "complete": True, "run_id": args.run_id, "head": args.head,
                "scope": "Single-pass fresh Rust release production; not IronRDP performance", "cells": rows,
            })
            print("QUALIFIED: all three fresh NVMe scaling releases", flush=True)
            print(json.dumps(rows, indent=2), flush=True)
            return
        time.sleep(120)
    raise TimeoutError("Scaling observer reached 74 hours; inspect remote state, do not restart builds")


if __name__ == "__main__":
    main()
