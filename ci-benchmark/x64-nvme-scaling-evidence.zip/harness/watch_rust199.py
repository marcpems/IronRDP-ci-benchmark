import argparse
import json
from pathlib import Path
import subprocess
import time

GH = r"D:\copilot\tools\gh\bin\gh.exe"
REPO = "marcpems/IronRDP-ci-benchmark"


def gh(*arguments):
    transient_errors = (
        "connectex:", "connection reset", "connection timed out",
        "i/o timeout", "tls handshake timeout", "temporary failure in name resolution",
        "error connecting to api.github.com",
        "http 502", "http 503", "http 504",
    )
    for attempt in range(1, 13):
        try:
            completed = subprocess.run(
                [GH, *arguments], text=True, capture_output=True, timeout=180)
        except subprocess.TimeoutExpired:
            error = "GitHub command timed out after 180 seconds"
        else:
            if completed.returncode == 0:
                return completed.stdout
            error = f"GitHub command failed: {completed.stderr.strip()}"
            if not any(marker in error.lower() for marker in transient_errors):
                raise RuntimeError(error)
        if attempt == 12:
            raise RuntimeError(f"GitHub connection retries exhausted: {error}")
        print(f"GitHub connection attempt {attempt}/12 failed; retrying in 60s: {error}",
              flush=True)
        time.sleep(60)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sha", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + 900
    while True:
        runs = json.loads(gh("run", "list", "--repo", REPO, "--branch", "experiment/x64-pgo-1991",
                             "--limit", "20", "--json", "databaseId,headSha,workflowName,status,url"))
        selected = [run for run in runs if run["headSha"] == args.sha
                    and run["workflowName"] == "Revalidate repaired LLVM PGO on Rust 1.99.1"]
        if selected:
            if len(selected) != 1:
                raise RuntimeError("Unexpected duplicate revalidation runs")
            run = selected[0]
            break
        if time.monotonic() > deadline:
            raise RuntimeError("Published workflow did not register within 15 minutes")
        time.sleep(15)
    save(args.output / "run.json", run)
    print(json.dumps(run), flush=True)
    deadline = time.monotonic() + 48 * 3600
    previous = None
    while time.monotonic() < deadline:
        current = json.loads(gh("run", "view", str(run["databaseId"]), "--repo", REPO,
                               "--json", "status,conclusion,jobs,url,headSha,createdAt,updatedAt"))
        save(args.output / "progress.json", current)
        status = [(job["name"], job["status"], job["conclusion"],
                   [(step["name"], step["status"]) for step in job["steps"] if step["status"] == "in_progress"])
                  for job in current["jobs"]]
        if status != previous:
            print(json.dumps(status), flush=True)
            previous = status
        if current["status"] == "completed":
            save(args.output / "completion.json", current)
            artifacts = json.loads(gh("api", f"repos/{REPO}/actions/runs/{run['databaseId']}/artifacts?per_page=100"))
            save(args.output / "artifacts.json", artifacts)
            for artifact in artifacts["artifacts"]:
                name = artifact["name"]
                if name.endswith("-evidence") or name == "x64-profile-replay":
                    gh("run", "download", str(run["databaseId"]), "--repo", REPO,
                       "--name", name, "--dir", str(args.output / "artifacts" / name))
            if current["conclusion"] != "success":
                (args.output / "failed.log").write_text(
                    gh("run", "view", str(run["databaseId"]), "--repo", REPO, "--log-failed"),
                    encoding="utf-8")
                raise RuntimeError(f"Revalidation concluded {current['conclusion']}; evidence retained")
            print("SUCCESS: all profile training, qualified distributions and replay evidence downloaded", flush=True)
            return
        time.sleep(90)
    raise TimeoutError("Revalidation remains incomplete after the monitoring deadline")


if __name__ == "__main__":
    main()
