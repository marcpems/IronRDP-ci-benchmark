import hashlib
import json
from pathlib import Path
import re
from zipfile import ZipFile, ZIP_DEFLATED

from watch_nvme_scaling import verify_cell

ROOT = Path(__file__).with_name("nvme-scaling-41054163612")
REPORT = Path(r"D:\copilot\IronRDP-matched-release\ci-benchmark")
HARNESS = Path(r"D:\copilot\IronRDP-nvme-scaling")
result = json.loads((ROOT / "verified-summary.json").read_text())
reference = None
manifest = {}
included = {}
for cell in result["cells"]:
    n = cell["workers"]
    evidence = ROOT / f"nvme-scaling-{n}-evidence"
    record, verified = verify_cell(evidence, n, reference, "41054163612")
    reference = reference or record
    for key, value in verified.items():
        if cell[key] != value:
            raise RuntimeError(f"Summary differs from raw receipts: {n}/{key}")
    for name, value in record["profiles"].items():
        with (evidence / f"{name}-pgo.profdata").open("rb") as stream:
            if hashlib.file_digest(stream, "sha256").hexdigest() != value["sha256"]:
                raise RuntimeError("Actual fresh profile bytes differ from recorded identity")
    topology = json.loads((evidence / "topology.json").read_text())
    if topology["selected_logical_processors"] != list(range(n)):
        raise RuntimeError("Topology and measured affinity disagree")
    cell["physical_cores_selected"] = topology["selected_physical_cores"]
    cell["effective_command_cores"] = cell["command_cpu_seconds"] / cell["command_wall_seconds"]
    sections = json.loads((evidence / "pipeline-sections.json").read_text())
    cell["sections"] = sections["completed"]
    cell["helper_and_other_production_seconds"] = cell["production_seconds"] - sum(
        value for key, value in cell["top_level_sections"].items() if key != "Run tests")
    tests = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; "
                       r"(\d+) measured; (\d+) filtered out;",
                       (evidence / "full-release.stdout").read_text(errors="replace"))
    totals = dict(zip(("passed", "failed", "ignored", "measured", "filtered"),
                      (sum(int(row[i]) for row in tests) for i in range(5))))
    if totals != {"passed": 25648, "failed": 0, "ignored": 739, "measured": 0, "filtered": 541}:
        raise RuntimeError(f"Unexpected extracted-test totals: {totals}")
    cell["qualification_tests"] = totals
    dist = json.loads((evidence / "dist-manifest.json").read_text())
    if len(dist) != 20 or any(item["bytes"] <= 0 or len(item["sha256"]) != 64 for item in dist):
        raise RuntimeError("Incomplete distribution manifest")
    cell["distribution_manifest"] = dist
    for path in sorted(evidence.iterdir()):
        if path.is_file():
            name = f"{n}lp/{path.name}"
            with path.open("rb") as stream:
                checksum = hashlib.file_digest(stream, "sha256").hexdigest()
            manifest[name] = {"bytes": path.stat().st_size, "sha256": checksum,
                              "included": path.suffix != ".profdata"}
            if path.suffix != ".profdata":
                included[name] = path
cells = {cell["workers"]: cell for cell in result["cells"]}
result["contrasts"] = {
    f"{b}lp_to_{t}lp": {
        "production_wall_reduction_percent": 100 * (1 - cells[t]["production_seconds"] / cells[b]["production_seconds"]),
        "production_speedup": cells[b]["production_seconds"] / cells[t]["production_seconds"],
        "whole_job_wall_reduction_percent": 100 * (1 - cells[t]["whole_job_seconds"] / cells[b]["whole_job_seconds"]),
    }
    for b, t in ((4, 8), (8, 16), (4, 16))
}
result["limits"] = (
    "Fixed order 16/8/4, one observation each, fresh profiles per cell; descriptive, no confidence interval. "
    "First N logical CPUs select 8/4/2 physical cores respectively, with both SMT siblings. "
    "Same NVMe filesystem throughout, not an isolated storage speedup. "
    "CPU receipts include qualification and measured helpers, not pure compiler CPU. "
    "Rust production, not IronRDP consumer performance. Distribution archive bytes remain in GitHub artifacts; "
    "their recorded hashes and passing extracted tests are preserved, not a new local extraction of every archive."
)
(REPORT / "x64-nvme-scaling-results.json").write_text(json.dumps(result, indent=2) + "\n")
for name in ("verified-summary.json", "completion.json", "artifacts.json"):
    included[f"run/{name}"] = ROOT / name
included["harness/watch_nvme_scaling.py"] = Path(__file__).with_name("watch_nvme_scaling.py")
included["harness/watch_rust199.py"] = Path(__file__).with_name("watch_rust199.py")
included["harness/publish_nvme_results.py"] = Path(__file__)
for name in (".github/scripts/x64_pr164707_validation.py", ".github/workflows/x64-nvme-scaling.yml",
             "ci-benchmark/x64-nvme-scaling-protocol.json"):
    included[f"harness/{name}"] = HARNESS / name
archive = REPORT / "x64-nvme-scaling-evidence.zip"
with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=9) as bundle:
    bundle.writestr("manifest.json", json.dumps(manifest, indent=2))
    bundle.write(REPORT / "x64-nvme-scaling-results.json", "results.json")
    for name, path in included.items():
        bundle.write(path, name)
with ZipFile(archive) as bundle:
    if bundle.testzip() is not None:
        raise RuntimeError("Evidence ZIP failed integrity validation")
with archive.open("rb") as stream:
    print("ZIP SHA256", hashlib.file_digest(stream, "sha256").hexdigest())
print("ZIP bytes", archive.stat().st_size)
print(json.dumps(result["contrasts"], indent=2))
